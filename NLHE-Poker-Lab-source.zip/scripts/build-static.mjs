import { mkdir, readFile, rm, writeFile, cp } from "node:fs/promises";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const publicDir = resolve(root, "public");
const distDir = resolve(root, "dist");
const files = {
  "/": ["index.html", "text/html; charset=utf-8"],
  "/index.html": ["index.html", "text/html; charset=utf-8"],
  "/app.css": ["app.css", "text/css; charset=utf-8"],
  "/app.js": ["app.js", "text/javascript; charset=utf-8"],
};
const binaryFiles = {
  "/NLHE-Poker-Lab-source.zip": ["NLHE-Poker-Lab-source.zip", "application/zip", 'attachment; filename="NLHE-Poker-Lab-source.zip"'],
};

const payload = {};
for (const [route, [file, type]] of Object.entries(files)) {
  payload[route] = { body: await readFile(resolve(publicDir, file), "utf8"), type };
}
for (const [route, [file, type, disposition]] of Object.entries(binaryFiles)) {
  payload[route] = { body: (await readFile(resolve(publicDir, file))).toString("base64"), type, disposition, base64: true };
}

if (!payload["/"].body.includes("NLHE Poker Lab") || !payload["/app.js"].body.includes("testSections")) {
  throw new Error("Site source is incomplete");
}

await rm(distDir, { recursive: true, force: true });
await mkdir(resolve(distDir, "server"), { recursive: true });
await cp(publicDir, resolve(distDir, "client"), { recursive: true });

const worker = `const assets=${JSON.stringify(payload)};
export default {
  async fetch(request) {
    const url = new URL(request.url);
    const asset = assets[url.pathname] || (url.pathname.startsWith("/assets/") ? null : assets["/"]);
    if (!asset) return new Response("Not found", { status: 404 });
    const body = asset.base64 ? Uint8Array.from(atob(asset.body), c => c.charCodeAt(0)) : asset.body;
    return new Response(body, {
      headers: {
        "content-type": asset.type,
        ...(asset.disposition ? { "content-disposition": asset.disposition } : {}),
        "cache-control": url.pathname === "/" || url.pathname === "/index.html" ? "no-cache" : "public, max-age=3600",
        "x-content-type-options": "nosniff",
        "referrer-policy": "strict-origin-when-cross-origin"
      }
    });
  }
};
`;

await writeFile(resolve(distDir, "server/index.js"), worker);

const standalone = payload["/"].body
  .replace('<link rel="stylesheet" href="./app.css" />', `<style>${payload["/app.css"].body}</style>`)
  .replace('<script src="./app.js" defer></script>', `<script>${payload["/app.js"].body.replaceAll("</script", "<\\/script")}</script>`);
await mkdir(resolve(root, "../outputs"), { recursive: true });
await Promise.all([
  writeFile(resolve(root, "../outputs/NLHE-Poker-Lab.html"), standalone),
  writeFile(resolve(root, "../outputs/NLHE-Poker-Lab-v1.1.html"), standalone),
]);
console.log(`Built NLHE Poker Lab (${Object.keys(payload).length} routes)`);
