import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, resolve } from "node:path";

const root = resolve(import.meta.dirname, "../public");
const port = Number(process.env.PORT || 4173);
const types = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8" };

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
    const requested = url.pathname === "/" ? "index.html" : url.pathname.slice(1);
    const safe = requested.includes("..") ? "index.html" : requested;
    const path = resolve(root, safe);
    const body = await readFile(path).catch(() => readFile(resolve(root, "index.html")));
    res.writeHead(200, { "content-type": types[extname(path)] || "text/html; charset=utf-8", "cache-control":"no-cache" });
    res.end(body);
  } catch (error) {
    res.writeHead(500, { "content-type":"text/plain; charset=utf-8" });
    res.end("Preview error");
  }
});

server.listen(port, "127.0.0.1", () => console.log(`Local: http://127.0.0.1:${port}/`));

