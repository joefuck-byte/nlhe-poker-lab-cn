import test from "node:test";
import assert from "node:assert/strict";

const worker = (await import("../dist/server/index.js")).default;

test("serves the learning dashboard", async () => {
  const response = await worker.fetch(new Request("https://example.test/"));
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /NLHE Poker Lab/);
  assert.match(html, /水平测试/);
  assert.match(html, /手牌复盘/);
});

test("serves interactive assets", async () => {
  const [css, js] = await Promise.all([
    worker.fetch(new Request("https://example.test/app.css")),
    worker.fetch(new Request("https://example.test/app.js")),
  ]);
  assert.match(css.headers.get("content-type"), /text\/css/);
  const source = await js.text();
  assert.match(source, /window\.localStorage/);
  assert.match(source, /storage \? storage\.getItem/);
  assert.doesNotMatch(source, /safeParse\(localStorage\.getItem/);
  assert.match(source, /dataset\.appReady/);
});

test("serves the MIT source bundle", async () => {
  const response = await worker.fetch(new Request("https://example.test/NLHE-Poker-Lab-source.zip"));
  const bytes = new Uint8Array(await response.arrayBuffer());
  assert.match(response.headers.get("content-type"), /application\/zip/);
  assert.match(response.headers.get("content-disposition"), /attachment/);
  assert.equal(String.fromCharCode(bytes[0], bytes[1]), "PK");
});
