# NLHE Poker Lab source

NLHE Poker Lab is a dependency-free Chinese poker study dashboard. It contains
the roadmap, bilingual glossary, diagnostic test, weekly training tracker,
player profile, and hand-review generator.

## Run locally

Open `public/index.html` in a modern browser, or run:

```sh
node scripts/dev-static.mjs
```

## Build

```sh
node scripts/build-static.mjs
```

The build creates a Cloudflare Worker-compatible entrypoint in
`dist/server/index.js` and a standalone HTML file in the project outputs.

## Data and privacy

The application has no analytics and sends no study data to a server. Browser
storage is used only for device-local progress when available.

## License

MIT. See `LICENSE`.

